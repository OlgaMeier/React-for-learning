import './styles.css';

function Homework18 () {
    return <div>Homework18</div>
}

export default Homework18;