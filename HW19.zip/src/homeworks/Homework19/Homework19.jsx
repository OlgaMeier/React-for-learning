

import React from 'react';
import Feedback  from '../../components/Feedback/Feedback';
import './styles.css';

function Homework19 () {
    return (
        <div className="homework19-container">
        <Feedback/>
        </div>
        );
}

export default Homework19;