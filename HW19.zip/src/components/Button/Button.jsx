import React from "react";
function Button() {
    return <button type="button">Create</button>;
  }
  
  export default Button;